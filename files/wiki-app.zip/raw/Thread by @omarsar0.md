---
title: "Thread by @omarsar0"
source: "https://x.com/omarsar0/status/2042286186920550498"
author:
  - "[[@omarsar0]]"
published: 2026-04-02
created: 2026-04-09
description: "Acabo de construir mi propio plugin generador de wikis para mis agentes. Mis agentes ahora pueden generar wikis para cualquier cosa que les"
tags:
  - "clippings"
---
**elvis** @omarsar0 2026-04-02

Acabo de construir mi propio plugin generador de wikis para mis agentes.

Mis agentes ahora pueden generar wikis para cualquier cosa que les pida.

Uno de mis wikis favoritos se llama PaperWiki.

Este es un gran ejemplo de lo que @karpathy describe.

Utiliza bóvedas de Obsidian para organizar artículos, recuperar resúmenes generados por LLM, diagramas y otras vistas avanzadas para la exploración de artículos.

Cuando la interfaz de usuario de Obsidian no es suficiente, uso mi propio generador de artefactos dentro de mi orquestador de agentes (ver clip para ejemplo). Esto permite que mis agentes construyan cualquier tipo de vista o función de exploración que necesite.

Los artículos están todos curados con automatizaciones y varias reglas/patrones que he construido manualmente a lo largo de los años.

En la superficie, esto parece básico. Pero detrás de escena, hay capacidades de búsqueda avanzadas, conexiones, metadatos, datos derivados y otros fragmentos de información interesantes que son extremadamente útiles para mis agentes de investigación. Esto está construido principalmente para agentes. La vista previa de artefactos es solo una forma de alto nivel para validar y evaluar rápidamente la calidad de la wiki, sugerir mejoras, y también es genial para la investigación.

Uso el qmd de @tobi para todas las capacidades de búsqueda.

Todo está en markdown. Los resúmenes e incluso los diagramas.

La wiki se actualiza por sí sola basándose en varias automatizaciones que he optimizado en las últimas semanas. La wiki crece y se auto-mejora basándose en varios requisitos importantes para mis casos de uso de investigación.

Esto es lo más personalizado que se puede conseguir. No hay nada como esto por ahí. Y uso mi experiencia en investigación para seguir mejorándolo con el tiempo.

Esta es una wiki vanilla. Hay tantas cosas que quiero construir encima de esto. Diferentes agregaciones, vistas, artefactos, etc. Todo para ayudar a automatizar más de mi trabajo de investigación y acelerar la productividad.

Creo que el mayor apalancamiento aquí es lo poderoso que podría ser esto para el descubrimiento y la experimentación. Uno de mis objetivos es usarlo para encontrar conexiones e insights más profundos que de otro modo eludirían a los mejores investigadores humanos y usar esos para generar hipótesis e experimentos de investigación interesantes y nuevos. De esa manera, mis agentes pueden usar autoresearch para explorar ideas de investigación en la frontera.

Manténganse atentos para más.

> 2026-04-02
> 
> Bases de Conocimiento de LLM
> 
> Algo que estoy encontrando muy útil recientemente: usar LLMs para construir bases de conocimiento personales para varios temas de interés de investigación. De esta manera, una gran fracción de mi rendimiento reciente de tokens se dirige menos a