---
title: "Thread by @clarincom"
source: "https://x.com/clarincom/status/2042354364438995331"
author:
  - "[[@clarincom]]"
published: 2026-04-09
created: 2026-04-09
description: "NUEVA ENCUESTA: EL PJ Y KICILLOF APARECEN ARRIBA DE LLA Y MILEI POR PRIMERA VEZ Un sondeo nacional de la consultora Trends muestra un deter"
tags:
  - "clippings"
---
**Clarín** @clarincom [2026-04-09](https://x.com/clarincom/status/2042354364438995331)

NUEVA ENCUESTA: EL PJ Y KICILLOF APARECEN ARRIBA DE LLA Y MILEI POR PRIMERA VEZ

Un sondeo nacional de la consultora Trends muestra un deterioro en la imagen del Gobierno, con peor evaluación de la economía, caída en la aprobación y dudas sobre la baja de la inflación. En un eventual balotaje, Axel Kicillof también aparece arriba de Javier Milei.

Los sentimientos negativos sobre el futuro del país alcanzan el 51% frente al 33% de los positivos. La aprobación de la gestión cayó a 39% y la desaprobación subió a 59%, mientras que la evaluación del rumbo del Gobierno pasó a 37% positiva y 57% negativa. Además, el 69% cree que la inflación no está bajando.

Intención de voto por espacios

— El peronismo de CFK y Axel Kicillof: 37%.

— La Libertad Avanza de Javier Milei: 35%.

— Provincias Unidas de Llaryora y Pullaro: 4%.

— Otro espacio político: 15%.

— Blanco/Nulo: 2%.

— Ns/Nc: 7%.

¿Cómo saldría un balotaje Milei vs. Kicillof?

— Axel Kicillof: 45%

— Javier Mieli: 42%

— Blanco/Nulo: 8%

— Ns/Nc: 5%

Ficha técnica

Relevamiento nacional de 2.000 casos, entrevistados entre el 29 y el 31 de marzo, con +/- 2,2% de margen de error

(+) en Clarín: https://clar.in/4chVo2u

![Imagen](https://pbs.twimg.com/media/HFffeSzW0AIlWVp?format=jpg&name=large)