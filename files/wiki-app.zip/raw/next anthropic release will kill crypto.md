---
title: "next anthropic release will kill crypto"
source: "https://x.com/the_smart_ape/status/2042177680326463572"
author:
  - "[[@the_smart_ape]]"
published: 2026-04-09
created: 2026-04-09
description: "ai is a machine economy.more software will act on its own.more agents will buy things, call tools, subscribe to services, delegate tasks, ne..."
tags:
  - "clippings"
---
ai is a machine economy.

more software will act on its own.

more agents will buy things, call tools, subscribe to services, delegate tasks, negotiate with other systems, and move value without a human manually approving every step.

[@cz\_binance](https://x.com/@cz_binance) and [@brian\_armstrong](https://x.com/@brian_armstrong) have already said that agents could eventually generate far more transactions than humans. maybe 1000x.

if ai starts doing a meaningful share of economic activity, then software needs native payment rails.

main questions are:

- how will agents exchange value?
- how will they pay for inference, storage, compute, services, data, and each other?

## tradfi is too human

the traditional financial system is not built for machine-native commerce.

it is built for institutions, legal entities, national borders, compliance stacks, bank accounts, settlement windows, and endless identity checks.

that model works, more or less, when humans are doing a manageable number of large transactions.

it works much worse when millions of agents need to do tiny, constant, low-latency exchanges.

just imagine what the current stack looks like from the perspective of a machine:

- onboarding requires kyc
- accounts are jurisdiction-bound
- settlement can be delayed
- fees are often too high for microtransactions
- integration is fragmented
- regulation is written for people and companies, not autonomous software

![Imagen](https://pbs.twimg.com/media/HFdCBLZXoAA6qZl?format=png&name=large)

tradfi will absolutely remain important.

but as a substrate for autonomous machine-to-machine exchange, it looks old.

## so crypto should win?

that is the default conclusion a lot of smart people jump to.

if agents need native internet money, and tradfi is too slow and too regulated, then surely crypto wins.

what if crypto is also the wrong answer? because the ai world has moved faster than crypto’s product-market fit.

## first problem: crypto still sucks at being money

after 15 years, billions in funding, and thousands of projects, crypto still has a surprisingly weak claim on real-world payments.

roughly 0.025% share of a roughly $40 trillion global payments market.

![Imagen](https://pbs.twimg.com/media/HFc5ZFhXkAAm92T?format=jpg&name=large)

whether you want to argue about the exact methodology or not, the direction is hard to deny.

- crypto is loud.
- crypto is liquid.
- crypto is global.
- crypto is very good at speculation.

but as a mainstream payment layer, it's still tiny relative to the promise.

and if you zoom in on the user experience, the progress is even less impressive than the marketing suggests.

wallets are cleaner. onboarding is a bit better. interfaces look nicer.

but the core process is still basically the same:

- manage keys
- sign transactions
- wait for finality
- accept weird UX
- pray you don’t mess up addresses, fees, bridges, or wallets

that’s still a human hobby with infrastructure ambitions.

## second problem: crypto is losing the infrastructure war

for years, bitcoin mining was one of the few large-scale monetization paths for energy-rich compute infrastructure.

if you had the building, the power, the cooling, and the hardware, mining was a rational business.

then ai showed up.

- same buildings.
- same power contracts.
- same cooling systems.
- same operational constraints.

different customer. different margins. different future.

around 12% post-halving margins for bitcoin mining. around 85% margins for ai data center leasing.

![Imagen](https://pbs.twimg.com/media/HFc6th8XIAAjqSO?format=jpg&name=large)

conclusion: if ai compute customers will pay you far more, for longer, on more stable contracts, your building stops being a mining site and becomes ai infrastructure. classic capital allocation.

ai has swallowed a giant share of global venture dollars.

around $211b into ai in 2025, up from $114b two years earlier.

and a funding ratio where ai now gets roughly $12 for every $1 going into crypto.

![Imagen](https://pbs.twimg.com/media/HFc7E9WXMAAz5E6?format=jpg&name=large)

once the capital moves, the buildings move. then the incentives move. then the talent moves.

## anthropic may be building something bigger

most people in crypto assume the future ai currency will be some token.

maybe stablecoins. maybe a new chain. maybe agent-specific payment rails. maybe some machine coin.

but what if the future ai-native currency is not a crypto asset at all?

what if it is already emerging inside ai infrastructure itself?

anthropic already operates something that behaves like a proto-currency.

not a currency in the fully legal, transferable, peer-to-peer sense. but a system with several monetary properties already in place.

## why claude tokens matter more than you realize

every api call to claude is measured in tokens.

if hundreds of thousands of organizations budget, forecast, optimize, and consume intelligence in tokens, then tokens start behaving like a unit of account.

if those tokens are exchanged for useful output in real time, then they start behaving like a medium of exchange.

![Imagen](https://pbs.twimg.com/media/HFc9NWrWsAAnpw9?format=png&name=large)

if they are backed by real, scarce, expensive, productive infrastructure, data centers, chips, power, inference capacity, then they begin to resemble a claim on productive capacity, not just a speculative ledger entry.

bitcoin burns energy to prove it burned energy. claude tokens burn energy to produce intelligence. one is a receipt. the other is a productive draw on infrastructure.

if the world is moving toward machine-native commerce, then the “money” that matters may be the thing that directly unlocks useful machine output. not the thing with the cleanest decentralization story.

## the settlement layer

one of the hardest parts of any monetary system is settlement.

- can value move reliably?
- can it clear fast?
- can it do so at scale?

anthropic already has enterprise billing and clearing infrastructure operating in real time, with near-instant settlement characteristics.

![Imagen](https://pbs.twimg.com/media/HFc-OmsWoAAfpcG?format=png&name=large)

again, this is not the same thing as a permissionless crypto network.

but if your main question is “how will machines pay for intelligence services at massive scale?”, then the answer may not be a public blockchain at all. it may be a vertically integrated infra stack where pricing, usage, settlement, and service delivery are all fused together.

that is a much more dangerous idea for crypto than most people realize.

because if that model wins, crypto does not lose because of regulation. it loses because it became unnecessary.

## and then there is mcp

anthropic did not just build a model company. it also helped build mcp, which is becoming a shared way for models and agents to connect to tools, systems, and services.

anthropic may accidentally build the protocol layer for the machine economy.

if bitcoin wanted to become the protocol for money, and anthropic ends up becoming part of the protocol for machine intelligence and machine commerce, then the center of gravity shifts.

money follows the protocol layer more often than you think.

just to be clear! anthropic will never launch a coin!

the real threat is that the next anthropic release keeps making claude, claude code, mcp, enterprise billing, and machine-to-machine workflows so useful that a huge chunk of economic activity starts flowing through anthropic-controlled rails by default.

if that happens, then crypto does not get replaced by a better coin. it gets bypassed by a better stack.

that’s much worse.

![Imagen](https://pbs.twimg.com/media/HFc_kysW8AAJnSf?format=png&name=large)

## what’s still missing?

there are still gaps:

- tokens are not peer-to-peer transferable like normal money
- there is no fully open agent-to-agent settlement layer yet
- external financial interoperability is limited
- and there are still governance and control questions

but point is that these look like product problems. not physics problems.

## conclusion

so no, i don’t think the next anthropic release literally kills crypto overnight.

but i do think the next anthropic release could make the crypto thesis look weaker in a much more serious way.

because every new release that expands:

- enterprise adoption
- machine-native billing
- mcp adoption
- claude code usage
- agent-to-tool orchestration
- and anthropic’s control over the stack

makes it more plausible that the ai economy will route around both tradfi and crypto in its own way.

tradfi is too slow and too human. crypto is still too awkward and too speculative.

and anthropic, almost by accident, may be building the first stack that feels native to machine commerce.