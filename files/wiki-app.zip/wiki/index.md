# Índice de la Wiki

- [Radar](dashboard.md)
- [Log](log.md)

## Fuentes
- [Dólar Ajustado Histórico](fuentes/dolar-historico-ajustado.md) — El dólar ajustado a precios de hoy cotiza cercano a mínimos registrados durante la gestión de Macri.
- [Expectativas de Inflación Mensual – IPC Nivel General (Marzo 2026)](fuentes/expectativas-inflacion-mensual-marzo-2026.md) — Fuente: REM - BCRA (mar-26).
- [Fuente: Gráfico HYPE/USDC (Hypertliquid)](fuentes/hype-usdc-chart-2026-04-09.md) — **Fecha de captura:** 2026-04-09
- [Hyperliquid (HYPE) - Análisis de Mercado](fuentes/hyperliquid-hype-2026-04-09.md) — **Fecha de ingestión:** 2026-04-09
- [Hyperliquid ($HYPE) Rally del 8,54% - Análisis Técnico y Fundamental](fuentes/hyperliquid-hype-rally-2026-04-08.md) — **Fecha de publicación:** 2026-04-08
- [ign.gob.ar - Actividad Petrolera Argentina](fuentes/ign-gob-ar.md) — Fuente oficial del Instituto Geológico y Minero de la Nación sobre producción petrolera en Argentina.
- [Fuente: Andy Stop Loss - Volviendo a la normalidad](fuentes/imagen-andy-stop-loss-2026-04-09.md) — **Fecha de ingestión:** 2026-04-09
- [Fuente: Imagen Pastilla WTI - 7 abr 2026](fuentes/imagen-pastilla-wti-2026-04-07.md) — Publicación de @cris tiannmillo mostrando caída drástica en WTI.
- [Fuente: Petróleo y Tregua en Medio Oriente](fuentes/petroleo-tregua-medio-oriente.md) — 2026-04-09
- [Relevamiento de Expectativas de Mercado (REM) - Marzo 2026](fuentes/rem-marzo-2026.md) — Según el REM, la encuesta local más abarcativa sobre proyecciones económicas del BCRA, se diluye la esperanza de que la economía retome el proceso de desinflación. Aun con un IPC d
- [Fuente: SECRETO DEFI (@SecretoDeFi)](fuentes/secreto-defi-hype-liquidaciones.md) — **Fecha de ingestión:** 2026-04-09
- [TACO: Trump Always Chickens Out](fuentes/taco-trump-always-chickens-out.md) — **TACO** es un acrónimo surgido en Wall Street que significa **"Trump Always Chickens Out"** ("Trump siempre se acobarda"). Se refiere a la dinámica observada tras la guerra arance
- [Declaración de Donald Trump sobre Militar y Irán](fuentes/trump-declaracion-militar-iran.md) — Publicado en el perfil oficial de X (Twitter) de @realDonaldTrump.
- [Fuente: Tweet de @TraderBCRA (09/04/2026)](fuentes/tw-traderbcra-2026-04-09.md) — **Autor:** TraderBCRA (@TraderBCRA)

## Senales
- [Señal: Caída drástica de WTI (-13.01%) el 7 abr 2026](senales/senal-caida-wti-2026-04-09.md) — ⚠️ **Señal temprana / Evento de volatilidad extrema**
- [Señal: Declaración Militar de Trump sobre Irán (Escalada Previa a la Tregua)](senales/senal-declaracion-militar-trump-iran-2026-04-09.md) — ⚠️ **Señal temprana / Evento de alta volatilidad**
- [Señal: Divergencia Crudo vs Bolsas Globales (WTI vs Asia/Europa/China)](senales/senal-divergencia-commodities-bolsas-2026-04-09.md) — ⚠️ **Señal temprana / Evento de volatilidad mixta**
- [Señal: Dólar Ajustado en Mínimos Históricos (Gestión Macri)](senales/senal-dolar-minimos-macri-2026-04-09.md) — ⚠️ **Señal temprana / Confirmación de patrón histórico**
- [Señal: Configuración de alertas en tiempo real para HYPE](senales/senal-hype-alertas-bot-2026-04-09.md) — ⚠️ **Señal temprana / Monitoreo activo**
- [Señal: Desbloqueo de tokens HYPE en abril añade presión de venta](senales/senal-hype-desbloqueo-april-2026.md) — ⚠️ **Señal temprana / Riesgo de liquidez**
- [Señal: Mapa de calor de liquidaciones HYPE muestra asimetría de riesgo](senales/senal-hype-liquidez-calor-2026-04-09.md) — ⚠️ **Señal temprana / Asimetría de liquidez**
- [Señal: Volumen explosivo de HYPE (+44%) confirma interés institucional](senales/senal-hype-volumen-explosivo-april-2026.md) — ⚠️ **Señal temprana / Confirmación de momentum**
- [Señal: HYPE muestra Open Interest masivo ($811M) con Funding negativo](senales/senal-hype-volumen-institucional-2026-04-09.md) — ⚠️ **Señal temprana / Divergencia de sentimiento**
- [Señal: Inflación estructural alta y revisiones al alza recurrentes](senales/senal-inflacion-piso-alto-y-revisiones.md) — ⚠️ **Señal temprana / Divergencia con narrativa de desinflación rápida**
- [Señal: Revisión al alza de expectativas inflacionarias (REM mar-26)](senales/senal-inflacion-revision-alza-marzo-2026.md) — ⚠️ **Señal temprana / Divergencia con pronóstico anterior**
- [Señal: Mercados US en fase de estabilización tras volatilidad](senales/senal-mercados-us-estabilizacion-april-2026.md) — ⚠️ **Señal temprana / Interpretación de 'Volviendo a la normalidad'**
- [Señal: Producción Petrolera Argentina supera los 800k barriles diarios](senales/senal-petroleo-record-vaca-muerta-2026-04-09.md) — En el periodo 2025-2026, la producción petrolera en Argentina superó los **800,000 barriles diarios**, impulsada principalmente por técnicas no convencionales en la formación de Va
- [Señal: TACO (Trump Always Chickens Out) revivido en abril 2026](senales/senal-taco-april-2026.md) — ⚠️ **Señal temprana / Dinámica de mercado observada**
- [Señal: Tregua en Medio Oriente abre el estrecho de Ormuz](senales/senal-tregua-medio-oriente-2026-04-09.md) — Anuncio de una tregua de dos semanas en la guerra de Medio Oriente tras bloqueos de Irán al estrecho de Ormuz, con apertura completa e inmediata del paso.

## Claims
- [Claim: El precio de WTI cayó más del 13% en un solo día](claims/clm-caida-wti-marcha-atras-2026-04-09.md) — El West Texas Intermediate (WTI) cerró el 7 de abril de 2026 en $95.98 USD, registrando una caída absoluta de -$14.36 (-13.01%) respecto a niveles anteriores superiores a $118.
- [Claim: Donald Trump ordenó el despliegue total de fuerzas militares alrededor de Irán](claims/clm-declaracion-militar-trump-iran-2026-04-08.md) — El 2026-04-08, Donald Trump declaró oficialmente que todas las naves, aviones y personal militar estadounidense permanecen en posición alrededor de Irán para la "lethal prosecution
- [Claim: WTI cierra negativo mientras bolsas globales suben (+0.6%)](claims/clm-divergencia-wti-bolsas-2026-04-09.md) — El precio del West Texas Intermediate (WTI) cerró en $99 USD el 2026-04-09, registrando una caída de -$4 desde la apertura de $103, mientras que los mercados accionarios globales (
- [Claim: El dólar ajustado actual está cerca de mínimos de la gestión Macri](claims/clm-dolar-minimos-macri-2026-04-09.md) — El tipo de cambio real (ajustado a precios locales) se encuentra en niveles comparables a los observados entre 2015 y 2018.
- [Claim: El mapa de calor de liquidaciones muestra asimetría extrema en HYPE](claims/clm-hype-asimetria-liquidez-2026-04-09.md) — El mapa de calor de liquidaciones para $HYPE muestra una concentración masiva de riesgo bajista por debajo de $35 y ausencia significativa de liquidez pendiente arriba de $40.
- [Claim: El desbloqueo de tokens HYPE en abril incrementa la oferta circulante](claims/clm-hype-desbloqueo-april-2026.md) — Se espera un aumento significativo en la oferta de tokens HYPE debido a un evento de desbloqueo programado para abril de 2026, lo que añade liquidez al mercado y podría ejercer pre
- [Claim: El precio de HYPE ($39k) muestra una correlación inversa con el petróleo crudo (WTI)](claims/clm-hype-oil-correlation-2026-04-09.md) — El precio de la criptomoneda Hyperliquid ($HYPE) cotiza en niveles superiores a $39,000 USDC, mientras que el petróleo WTI cierra en mínimos recientes (~$99 USD), sugiriendo una de
- [Claim: El volumen de HYPE (+44%) confirma interés genuino en abril](claims/clm-hype-volumen-44pct-april-2026.md) — El volumen diario de $HYPE el 2026-04-08 fue de USD $447,59 MM, un **+44,65%** superior al promedio de 30 días, indicando entrada real de capital y no solo manipulación o hype.
- [Claim: La inflación anual proyectada para 2026 se revisó al alza significativamente](claims/clm-inflacion-anual-revision-alza-2026.md) — La proyección de inflación anual para Argentina en 2026, según la mediana del REM de marzo, se situó en 29.1% i.a., representando un incremento de +3.1 puntos porcentuales respecto
- [Claim: La inflación anual proyectada para 2026 (TOP-10) es de 31,8%](claims/clm-inflacion-anual-top10-2026.md) — La proyección de inflación anual para Argentina en 2026, según el promedio del Top 10 del REM de marzo, se situó en 31,8% i.a., representando un incremento de +4,0 puntos porcentua
- [Claim: Los índices estadounidenses muestran consolidación suave en abril](claims/clm-mercados-us-consolidacion-suave-april-2026.md) — El S&P 500, Dow Jones y NASDAQ 100 muestran caídas leves (-0.16%, -0.08%, -0.23% respectivamente) el 2026-04-09, sugiriendo un mercado en consolidación o corrección suave.
- [Claim: Argentina busca superar el millón de barriles diarios en exportaciones para 2028](claims/clm-petroleo-exportacion-meta-2028.md) — Con una producción creciente impulsada por Vaca Muerta, Argentina tiene como objetivo principal superar el **millón de barriles diarios** en exportaciones para el año 2028.
- [Claim: El patrón TACO (Trump Always Chickens Out) se activó en abril 2026 tras la crisis de Ormuz](claims/clm-taco-april-2026.md) — La dinámica de mercado conocida como **TACO** (*Trump Always Chickens Out*) se manifestó claramente en abril de 2026: Trump emitió amenazas militares severas contra Irán y el cierr
- [Claim: El estrecho de Ormuz está abierto tras la tregua](claims/clm-tregua-ormuz-abierta-2026-04-09.md) — La tregua de dos semanas incluye la apertura completa, inmediata y segura del estrecho de Ormuz, eliminando el bloqueo impuesto por Irán como represalia bélica.

## Hipotesis
- [Hipótesis: La caída de WTI (-13%) es una reacción a un evento específico o noticia](hipotesis/tesis-caida-wti-evento-especifico.md) — El movimiento alcista significativo en el petróleo (WTI) (+2.58%) observado simultáneamente por Andy Stop Loss, mientras que Bitcoin, Oro y Plata caen ligeramente, podría indicar:
- [Hipótesis: La caída de WTI (-$4) es una corrección técnica independiente del riesgo global](hipotesis/tesis-divergencia-energia-risco-2026-04-09.md) — La divergencia observada (WTI bajista vs Bolsas alcistas) sugiere que la caída del crudo no está impulsada por un cambio en el apetito por el riesgo general (que sería alcista para
- [Hipótesis: Desincronización entre Dólar Ajustado e Inflación](hipotesis/tesis-dolar-inflacion-desincronizada.md) — A pesar de las proyecciones del REM (Marzo 2026) que indican una inflación anual estimada del 31.8% y un ritmo de ajuste con pico en marzo, el dólar ajustado no ha subido proporcio
- [Hipótesis: La declaración militar de Trump valida el patrón TACO en abril 2026](hipotesis/tesis-escalada-trump-iran-valida-taco.md) — La amenaza extrema emitida por Trump el 2026-04-08 (despliegue total y "Shootin' Starts") no fue una escalada irreversible, sino un componente necesario del patrón **TACO** (*Trump
- [Hipótesis: El momentum alcista de HYPE se sustenta en la utilidad de DeFi Perpetuals, no solo en especulación](hipotesis/tesis-hype-defi-perpetuals-momentum-2026-04-09.md) — La subida del precio de $HYPE (de ~$31k a ~$39k) y el volumen explosivo ($256M+) están impulsados por la adopción real de su protocolo de contratos perpetuos (bajo slippage, fees e
- [Hipótesis: El desbloqueo de abril actuará como resistencia clave al rally de HYPE](hipotesis/tesis-hype-desbloqueo-april-resistencia.md) — El evento de desbloqueo de tokens en abril generará suficiente presión de venta para limitar el rally alcista actual, creando una zona de resistencia técnica antes de que el precio
- [Hipótesis: La asimetría de liquidez en HYPE favorece un "fall trap" bajista antes de la siguiente fase alcista](hipotesis/tesis-hype-liquidez-asimetrica.md) — La concentración de posiciones largas esperando liquidación por debajo de $35 (especialmente cerca de $28-$31) sugiere que cualquier corrección rápida podría desencadenar una casca
- [Hipótesis: El volumen explosivo (+44%) sustenta el rally alcista de HYPE en abril](hipotesis/tesis-hype-volumen-sustenta-alcista-april.md) — El incremento del volumen a USD $447,59 MM (+44% vs 30 días) no es un evento aislado, sino que confirma una tesis alcista de corto plazo impulsada por la utilidad de DeFi perpetuos
- [Hipótesis: El piso inflacionario está determinado por el efecto arrastre de combustibles y tarifas](hipotesis/tesis-inflacion-estructural-combustibles.md) — La inflación anual proyectada (31,8% TOP-10) no es solo una proyección estadística, sino que responde a factores estructurales específicos identificados en el REM: la subida del 25
- [Hipótesis: El piso inflacionario es más alto del proyectado y las revisiones al alza son recurrentes](hipotesis/tesis-inflacion-piso-alto-y-revisiones.md) — A pesar de la tendencia descendente mensual proyectada en el REM (de 3.0% a 1.8%), la inflación estructural se mantiene alta (29-31% anual) y los economistas han revisado sistemáti
- [Hipótesis: La producción de Vaca Muerta garantiza autonomía energética por más de una década](hipotesis/tesis-petroleo-autonomia-energetica.md) — La capacidad productiva actual (superando los 800,000 barriles diarios) y las reservas probadas de aproximadamente 3.000 millones de barriles garantizan la autonomía energética de 
- [Hipótesis: El rally del petróleo (+2.58%) es una reacción técnica o noticia específica](hipotesis/tesis-petroleo-reaccion-tecnica-april-2026.md) — El movimiento alcista significativo en el petróleo (WTI) (+2.58%) mientras que Bitcoin, Oro y Plata caen ligeramente, podría indicar:
- [Hipótesis: El precio del petróleo es altamente sensible a la resolución geopolítica inmediata](hipotesis/tesis-precio-petroleo-sensibilidad-geopolitica.md) — La caída abrupta de WTI (-14,6%) tras el anuncio de la tregua y apertura de Ormuz sugiere que el mercado estaba descontando un escenario de bloqueo total o interrupción severa del 
- [Hipótesis: La estrategia operativa TACO es un patrón de volatilidad predecible en la administración Trump](hipotesis/tesis-taco-estrategia-operativa.md) — El acrónimo **TACO** (*Trump Always Chickens Out*) no es solo una anécdota, sino una estrategia operativa válida para trading de muy corto plazo. La hipótesis sugiere que existe un

## Escenarios
- [Escenario: Crisis Energética Global por Bloqueo del Estrecho de Ormuz](escenarios/escenario-crisis-energetica-global-ormuz.md) — - **Evento:** Declaración de Trump sobre despliegue militar y amenaza de "Shootin' Starts".
- [Escenario: Inflación Permanente sobre el 30% en 2026](escenarios/escenario-inflacion-alta-2026.md) — La inflación anual para Argentina en 2026 se mantiene por encima del 30%, impulsada por factores estructurales (combustibles, tarifas) y una revisión sistemática al alza de las exp
- [Escenario: Inflación Permanente sobre el 25% en 2026](escenarios/escenario-inflacion-permanente-sobre-25.md) — - Inflación anual proyectada (Mediana REM): 29.1%.
- [Escenario: Repetición del 'Sudden-Stop' de 2018](escenarios/escenario-sudden-stop-2026.md) — - Dólar ajustado en mínimos históricos ($2.400 - $2.676).

## Acciones
- [Acción: Monitoreo del Dólar Ajustado vs Inflación](acciones/accion-monitorear-dolar-ajustado.md) — Validar si la hipótesis de desincronización entre dólar ajustado e inflación se confirma.
- [Acción: Validar la credibilidad de la amenaza militar de Trump y su impacto en precios](acciones/accion-validar-amenaza-trump-iran.md) — Determinar si la declaración del 2026-04-08 fue una maniobra táctica para presionar a Irán (y obtener concesiones como la tregua) o un intento genuino de iniciar un conflicto.
- [Acción: Validar la asimetría de liquidez y su impacto en el precio de HYPE](acciones/accion-validar-asimetria-liquidez-hype.md) — Determinar si la concentración de posiciones largas por debajo de $35 actuará como un catalizador de volatilidad bajista (fall trap) o si será absorbida sin afectar significativame
- [Acción: Validar la causa de la caída drástica de WTI](acciones/accion-validar-caida-wti-2026-04-09.md) — Determinar si la caída del 13% en WTI fue impulsada por un evento fundamental (geopolítico, oferta) o puramente técnico/psicológico.
- [Acción: Validar la correlación entre HYPE y commodities (WTI/Brent)](acciones/accion-validar-correlacion-hype-petroleo-2026-04-09.md) — Determinar si el rally de $HYPE (+1.75%) es independiente del mercado de materias primas o si existe una desconexión estructural.
- [Acción: Validar el impacto del desbloqueo de tokens en abril](acciones/accion-validar-desbloqueo-april.md) — Determinar si el desbloqueo de tokens mencionado por CMC AI ejercerá presión bajista real sobre el precio de HYPE o será absorbido sin afectar significativamente la tendencia alcis
- [Acción: Validar la divergencia WTI vs Bolsas Globales](acciones/accion-validar-divergencia-traderbcra-2026-04-09.md) — Determinar si la caída de WTI (-$4) mientras las bolsas suben (+0.6%) es un evento aislado o el inicio de una tendencia de desacoplamiento estructural.
- [Acción: Validar el impacto a largo plazo de la tregua en los precios del petróleo](acciones/accion-validar-impacto-tregua-petroleo.md) — Determinar si la caída de WTI (-14,6%) es una corrección temporal o el inicio de una tendencia bajista sostenida hacia niveles pre-tensión.
- [Acción: Validar el progreso hacia la meta de exportaciones de 1 millón de barriles diarios](acciones/accion-validar-meta-exportaciones-2028.md) — Determinar si Argentina está en camino de superar el millón de barriles diarios en exportaciones para 2028, tal como lo indica el Instituto Geológico y Minero de la Nación.
- [Acción: Validar la narrativa de "Volviendo a la normalidad"](acciones/accion-validar-narrativa-normalidad-april-2026.md) — Determinar si la percepción de estabilización del mercado (BTC en zona baja de $70k, índices consolidando) es una tendencia estructural o un evento transitorio.
- [Acción: Validar la consistencia de las revisiones al alza en el REM](acciones/accion-validar-revisiones-inflacion.md) — Determinar si la tendencia de revisiones al alza en el REM (noveno informe consecutivo) es un patrón estructural o una anomalía temporal.
- [Acción: Validar la estrategia operativa TACO en futuros eventos geopolíticos](acciones/accion-validar-taco-futuros.md) — Determinar si el patrón **TACO** (*Trump Always Chickens Out*) se repite en próximas escaladas militares o arancelarias para explotar oportunidades de trading de corto plazo.
- [Acción: Validar la sostenibilidad del volumen en HYPE](acciones/accion-validar-volumen-hype-april-2026.md) — Determinar si el volumen explosivo (+44%) se mantiene al superar las resistencias de USD $41,50 y USD $45, o si es un pico aislado.

## Entidades
- [Banco Central de la República Argentina (BCRA)](entidades/bcra.md) — Institución encargada de realizar el Relevamiento de Expectativas de Mercado (REM), la encuesta local más abarcativa sobre proyecciones económicas.
- [Brent](entidades/brent.md) — El petróleo Brent es un tipo de crudo que sirve como referencia internacional para la fijación de precios del petróleo.
- [Hyperliquid ($HYPE)](entidades/hyperliquid-hype.md) — **Tipo:** Criptomoneda / DeFi Perpetuals
- [PAE (Petrobras Argentina)](entidades/pae.md) — Empresa petrolera argentina involucrada en el desarrollo de recursos no convencionales.
- [REM (Encuesta de Economistas)](entidades/rem.md) — **REM** es la sigla para *Research Economics Monthly*, una encuesta mensual realizada por el Banco Central de la República Argentina (BCRA) a un grupo de economistas.
- [TACO](entidades/taco.md) — Acrónimo / Término de Mercado
- [Vaca Muerta](entidades/vaca-muerta.md) — Formación geológica en la Cuenca Neuquina que alberga los mayores yacimientos de shale oil de Argentina.
- [Vista Petroleum](entidades/vista-petroleum.md) — Empresa internacional con presencia significativa en shale oil argentino.
- [WTI (West Texas Intermediate)](entidades/wti.md) — El West Texas Intermediate es un tipo de petróleo crudo que sirve como referencia para la fijación de precios del petróleo en los mercados globales.
- [YPF](entidades/ypf.md) — Empresa estatal argentina líder en producción petrolera nacional.

## Conceptos
- [Cuenca Neuquina](conceptos/cuenca-neuquina.md) — Formación geológica principal de Argentina para producción petrolera.
- [Dólar Ajustado](conceptos/dolar-ajustado.md) — El **dólar ajustado** es una medida que refleja el valor del dólar estadounidense expresado en términos de precios locales actuales, permitiendo comparar cotizaciones históricas co
- [Mercados Globales](conceptos/mercados-globales.md) — Conjunto de bolsas y mercados financieros internacionales que operan en diferentes zonas geográficas.
- [Petróleo](conceptos/petroleo.md) — Hidrocarburo líquido utilizado como combustible principal para la industria y el transporte mundial.
- [Producción Récord Petróleo Argentina](conceptos/produccion-record-petroleo.md) — - **Febrero 2026**: ~866,000 barriles diarios (récord histórico)
- [Shale Oil Argentina](conceptos/shale-oil.md) — Petróleo extraído de formaciones rocosas no convencionales mediante técnicas de fracturación hidráulica.

## Templates
- [Action Template](templates/action-template.md) — type: accion
- [Claim Template](templates/claim-template.md) — type: claim
- [Hypothesis Template](templates/hypothesis-template.md) — type: hipotesis
- [Scenario Template](templates/scenario-template.md) — type: escenario
- [Signal Template](templates/signal-template.md) — type: senal

## Otros
- [Bienvenido](wiki-app-alan2/Bienvenido.md) — Esta es su nueva *bóveda*.
- [Sin Título](wiki-app-alan2/Sin título.md) — Sin resumen todavía.

---
*Última actualización: 2026-04-09 22:06*
