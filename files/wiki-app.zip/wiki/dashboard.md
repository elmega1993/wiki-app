# Radar

## Resumen
- Fuentes: 14
- Señales: 15
- Claims: 14
- Narrativas: 0
- Hipótesis: 14
- Escenarios: 4
- Acciones: 13
- Temas: 0
- Entidades: 10
- Conceptos: 6
- Consultas archivadas: 0

## Reciente
- [Acción: Validar la divergencia WTI vs Bolsas Globales](acciones/accion-validar-divergencia-traderbcra-2026-04-09.md) — acciones
- [Hipótesis: La caída de WTI (-$4) es una corrección técnica independiente del riesgo global](hipotesis/tesis-divergencia-energia-risco-2026-04-09.md) — hipotesis
- [Claim: WTI cierra negativo mientras bolsas globales suben (+0.6%)](claims/clm-divergencia-wti-bolsas-2026-04-09.md) — claims
- [Señal: Divergencia Crudo vs Bolsas Globales (WTI vs Asia/Europa/China)](senales/senal-divergencia-commodities-bolsas-2026-04-09.md) — senales
- [Fuente: Tweet de @TraderBCRA (09/04/2026)](fuentes/tw-traderbcra-2026-04-09.md) — fuentes
- [Acción: Validar la credibilidad de la amenaza militar de Trump y su impacto en precios](acciones/accion-validar-amenaza-trump-iran.md) — acciones
- [Escenario: Crisis Energética Global por Bloqueo del Estrecho de Ormuz](escenarios/escenario-crisis-energetica-global-ormuz.md) — escenarios
- [Hipótesis: La declaración militar de Trump valida el patrón TACO en abril 2026](hipotesis/tesis-escalada-trump-iran-valida-taco.md) — hipotesis

## Hipótesis activas
- [Hipótesis: La caída de WTI (-13%) es una reacción a un evento específico o noticia](hipotesis/tesis-caida-wti-evento-especifico.md) — status: s/d
- [Hipótesis: La caída de WTI (-$4) es una corrección técnica independiente del riesgo global](hipotesis/tesis-divergencia-energia-risco-2026-04-09.md) — status: s/d
- [Hipótesis: Desincronización entre Dólar Ajustado e Inflación](hipotesis/tesis-dolar-inflacion-desincronizada.md) — status: s/d
- [Hipótesis: La declaración militar de Trump valida el patrón TACO en abril 2026](hipotesis/tesis-escalada-trump-iran-valida-taco.md) — status: s/d
- [Hipótesis: El momentum alcista de HYPE se sustenta en la utilidad de DeFi Perpetuals, no solo en especulación](hipotesis/tesis-hype-defi-perpetuals-momentum-2026-04-09.md) — status: s/d
- [Hipótesis: El desbloqueo de abril actuará como resistencia clave al rally de HYPE](hipotesis/tesis-hype-desbloqueo-april-resistencia.md) — status: s/d
- [Hipótesis: La asimetría de liquidez en HYPE favorece un "fall trap" bajista antes de la siguiente fase alcista](hipotesis/tesis-hype-liquidez-asimetrica.md) — status: s/d
- [Hipótesis: El volumen explosivo (+44%) sustenta el rally alcista de HYPE en abril](hipotesis/tesis-hype-volumen-sustenta-alcista-april.md) — status: s/d

---
*Última actualización: 2026-04-09 22:06*
