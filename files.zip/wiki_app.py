#!/usr/bin/env python3
"""
Finanzas Wiki — App de escritorio
Conecta con LM Studio local para construir una wiki de finanzas personal.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import json
import os
import re
import base64
from datetime import datetime
from pathlib import Path
import urllib.request
import urllib.error

# ── Configuración ──────────────────────────────────────────────────────────────
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"
MODEL_NAME     = "qwen/qwen3.5-9b"
WIKI_DIR       = Path("wiki")
RAW_DIR        = Path("raw")

SCHEMA = """Sos un asistente especializado en mantener una wiki de finanzas.
La wiki vive en archivos markdown organizados así:
  wiki/entidades/   — empresas, ETFs, activos, brokers
  wiki/conceptos/   — inflación, tasas, CEDEARs, dólar, etc.
  wiki/fuentes/     — resúmenes de cada fuente ingerida
  wiki/index.md     — índice de todo el contenido
  wiki/log.md       — registro cronológico de operaciones

## Al INGERIR una fuente:
Devolvé SOLO un JSON con este formato exacto (sin markdown, sin texto extra):
{
  "operacion": "ingest",
  "paginas": [
    {"ruta": "wiki/fuentes/nombre.md", "contenido": "...markdown..."},
    {"ruta": "wiki/entidades/empresa.md", "contenido": "...markdown..."}
  ],
  "resumen": "Breve descripción de lo que se procesó"
}

## Al RESPONDER una consulta:
Devolvé SOLO un JSON:
{
  "operacion": "query",
  "respuesta": "Tu respuesta en markdown",
  "archivar": false
}

## Al hacer LINT:
Devolvé SOLO un JSON:
{
  "operacion": "lint",
  "problemas": ["descripción de problema 1", "..."],
  "sugerencias": ["sugerencia 1", "..."]
}

Reglas importantes:
- Marcá contradicciones con ⚠️
- Siempre actualizá wiki/index.md y wiki/log.md
- Usá fechas en formato YYYY-MM-DD
- Para finanzas argentinas considerá: ARS, USD, dólar blue, MEP, CCL, CEDEARs, MERVAL
"""

# ── Colores / tema ─────────────────────────────────────────────────────────────
BG        = "#0d1117"
BG2       = "#161b22"
BG3       = "#21262d"
ACCENT    = "#f0b429"   # dorado financiero
ACCENT2   = "#3fb950"   # verde profit
ACCENT3   = "#f85149"   # rojo loss
FG        = "#e6edf3"
FG2       = "#8b949e"
BORDER    = "#30363d"
FONT_MONO = ("Courier New", 10)
FONT_UI   = ("Segoe UI", 10)
FONT_BIG  = ("Segoe UI", 13, "bold")
FONT_MED  = ("Segoe UI", 11)

# ── Utilidades de archivo ──────────────────────────────────────────────────────

def ensure_dirs():
    for d in [WIKI_DIR, RAW_DIR,
              WIKI_DIR/"entidades", WIKI_DIR/"conceptos", WIKI_DIR/"fuentes"]:
        d.mkdir(parents=True, exist_ok=True)
    if not (WIKI_DIR/"index.md").exists():
        (WIKI_DIR/"index.md").write_text("# Índice de la Wiki\n\n*Vacío — ingresá tu primera fuente.*\n")
    if not (WIKI_DIR/"log.md").exists():
        (WIKI_DIR/"log.md").write_text("# Log de operaciones\n\n")

def read_wiki_context():
    """Lee index.md y log.md para dar contexto al modelo."""
    parts = []
    for f in [WIKI_DIR/"index.md", WIKI_DIR/"log.md"]:
        if f.exists():
            parts.append(f"### {f.name}\n{f.read_text()}")
    return "\n\n".join(parts)

def save_pages(pages: list):
    """Escribe las páginas devueltas por el modelo."""
    saved = []
    for p in pages:
        path = Path(p["ruta"])
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(p["contenido"], encoding="utf-8")
        saved.append(str(path))
    return saved

def image_to_base64(path: str) -> tuple[str, str]:
    ext = Path(path).suffix.lower()
    mime = {"jpg": "image/jpeg", ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg", ".png": "image/png",
            ".gif": "image/gif", ".webp": "image/webp"}.get(ext, "image/png")
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode(), mime

def extract_pdf_text(path: str) -> str:
    """Extrae texto de PDF usando pdfminer si está disponible, sino básico."""
    try:
        from pdfminer.high_level import extract_text
        return extract_text(path)
    except ImportError:
        pass
    try:
        import subprocess
        result = subprocess.run(["pdftotext", path, "-"], capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout
    except Exception:
        pass
    return f"[PDF: {Path(path).name} — instalá pdfminer.six para extraer texto: pip install pdfminer.six]"

# ── Llamada al modelo ──────────────────────────────────────────────────────────

def call_lm_studio(messages: list, timeout: int = 120) -> str:
    payload = {
        "model": MODEL_NAME,
        "messages": messages,
        "temperature": 0.2,
        "max_tokens": 4096,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        LM_STUDIO_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode())
            return result["choices"][0]["message"]["content"]
    except urllib.error.URLError as e:
        raise ConnectionError(f"No se pudo conectar a LM Studio: {e.reason}")

def parse_json_response(raw: str) -> dict:
    """Extrae JSON de la respuesta aunque venga con markdown."""
    raw = raw.strip()
    # quitar bloques ```json ... ```
    raw = re.sub(r"```(?:json)?\s*", "", raw)
    raw = re.sub(r"```", "", raw)
    # buscar primer { hasta el último }
    start = raw.find("{")
    end   = raw.rfind("}") + 1
    if start == -1:
        raise ValueError("No se encontró JSON en la respuesta")
    return json.loads(raw[start:end])

# ── App principal ──────────────────────────────────────────────────────────────

class WikiApp(tk.Tk):
    def __init__(self):
        super().__init__()
        ensure_dirs()
        self.title("Finanzas Wiki  ·  LM Studio")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(bg=BG)
        self._build_ui()
        self._refresh_tree()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        self.columnconfigure(0, weight=0)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        # ── Panel izquierdo ──
        left = tk.Frame(self, bg=BG2, width=240)
        left.grid(row=0, column=0, sticky="nsew")
        left.grid_propagate(False)
        left.rowconfigure(3, weight=1)
        left.columnconfigure(0, weight=1)

        # Logo / título
        hdr = tk.Frame(left, bg=BG2, pady=16)
        hdr.grid(row=0, column=0, sticky="ew")
        tk.Label(hdr, text="₿ Finanzas Wiki", font=FONT_BIG,
                 bg=BG2, fg=ACCENT).pack()
        tk.Label(hdr, text="powered by LM Studio", font=("Segoe UI", 8),
                 bg=BG2, fg=FG2).pack()

        sep = tk.Frame(left, bg=BORDER, height=1)
        sep.grid(row=1, column=0, sticky="ew")

        # Botones de acción
        btns = tk.Frame(left, bg=BG2, pady=8, padx=12)
        btns.grid(row=2, column=0, sticky="ew")
        btns.columnconfigure(0, weight=1)

        def btn(parent, text, cmd, color=ACCENT, row=0):
            b = tk.Button(parent, text=text, command=cmd,
                          bg=color, fg=BG, font=("Segoe UI", 9, "bold"),
                          relief="flat", cursor="hand2",
                          activebackground=color, activeforeground=BG,
                          padx=10, pady=7)
            b.grid(row=row, column=0, sticky="ew", pady=3)
            return b

        btn(btns, "＋  Ingerir fuente",   self._open_ingest,  ACCENT,  0)
        btn(btns, "🔍  Consultar wiki",    self._open_query,   "#388bfd", 1)
        btn(btns, "🛠  Lint (salud)",      self._run_lint,     BG3,     2)
        btn(btns, "⟳  Actualizar árbol",  self._refresh_tree, BG3,     3)

        # Árbol de archivos
        tree_frame = tk.Frame(left, bg=BG2)
        tree_frame.grid(row=3, column=0, sticky="nsew", padx=8, pady=4)
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Wiki.Treeview",
                         background=BG2, foreground=FG, fieldbackground=BG2,
                         borderwidth=0, rowheight=22, font=FONT_UI)
        style.configure("Wiki.Treeview.Heading",
                         background=BG3, foreground=FG2, borderwidth=0)
        style.map("Wiki.Treeview",
                  background=[("selected", BG3)],
                  foreground=[("selected", ACCENT)])

        self.tree = ttk.Treeview(tree_frame, style="Wiki.Treeview", show="tree")
        self.tree.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)

        # Indicador de conexión
        self.conn_label = tk.Label(left, text="● LM Studio", font=("Segoe UI", 8),
                                   bg=BG2, fg=ACCENT2)
        self.conn_label.grid(row=4, column=0, pady=6)

        # ── Panel derecho ──
        right = tk.Frame(self, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        right.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)

        # Barra superior
        topbar = tk.Frame(right, bg=BG3, height=40)
        topbar.grid(row=0, column=0, sticky="ew")
        topbar.grid_propagate(False)
        topbar.columnconfigure(1, weight=1)

        self.page_title = tk.Label(topbar, text="Seleccioná un archivo",
                                   font=FONT_MED, bg=BG3, fg=FG2, padx=16)
        self.page_title.grid(row=0, column=0, sticky="w", pady=8)

        self.model_label = tk.Label(topbar, text=f"modelo: {MODEL_NAME}",
                                    font=("Segoe UI", 8), bg=BG3, fg=FG2, padx=16)
        self.model_label.grid(row=0, column=2, sticky="e")

        # Editor de contenido
        editor_frame = tk.Frame(right, bg=BG)
        editor_frame.grid(row=1, column=0, sticky="nsew", padx=12, pady=8)
        editor_frame.rowconfigure(0, weight=1)
        editor_frame.columnconfigure(0, weight=1)

        self.editor = scrolledtext.ScrolledText(
            editor_frame,
            bg=BG2, fg=FG, insertbackground=ACCENT,
            font=FONT_MONO, relief="flat", borderwidth=0,
            wrap="word", padx=16, pady=12,
            selectbackground=BG3, selectforeground=ACCENT
        )
        self.editor.grid(row=0, column=0, sticky="nsew")

        # Barra de estado
        self.status = tk.Label(right, text="Listo.",
                               font=("Segoe UI", 8), bg=BG3, fg=FG2,
                               anchor="w", padx=12, pady=4)
        self.status.grid(row=2, column=0, sticky="ew")

    # ── Árbol ─────────────────────────────────────────────────────────────────

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())

        def add_dir(parent, path: Path):
            for item in sorted(path.iterdir()):
                if item.name.startswith("."):
                    continue
                if item.is_dir():
                    node = self.tree.insert(parent, "end",
                                            text=f"📁 {item.name}",
                                            values=[str(item)])
                    add_dir(node, item)
                elif item.suffix == ".md":
                    self.tree.insert(parent, "end",
                                     text=f"📄 {item.name}",
                                     values=[str(item)])

        if WIKI_DIR.exists():
            root = self.tree.insert("", "end", text="📂 wiki", values=[str(WIKI_DIR)], open=True)
            add_dir(root, WIKI_DIR)

    def _on_tree_select(self, _event):
        sel = self.tree.selection()
        if not sel:
            return
        vals = self.tree.item(sel[0], "values")
        if not vals:
            return
        path = Path(vals[0])
        if path.is_file():
            self.page_title.config(text=str(path))
            content = path.read_text(encoding="utf-8")
            self.editor.config(state="normal")
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", content)

    # ── Ingerir ───────────────────────────────────────────────────────────────

    def _open_ingest(self):
        win = tk.Toplevel(self)
        win.title("Ingerir fuente")
        win.geometry("620x500")
        win.configure(bg=BG)
        win.grab_set()

        tk.Label(win, text="Ingerir fuente nueva", font=FONT_BIG,
                 bg=BG, fg=ACCENT).pack(pady=(20, 4))
        tk.Label(win, text="Pegá texto, o seleccioná un archivo PDF/imagen",
                 font=FONT_UI, bg=BG, fg=FG2).pack()

        # Área de texto
        txt = scrolledtext.ScrolledText(win, bg=BG2, fg=FG, font=FONT_MONO,
                                         relief="flat", borderwidth=1,
                                         insertbackground=ACCENT,
                                         height=14, padx=10, pady=8)
        txt.pack(fill="both", expand=True, padx=20, pady=12)

        self._ingest_file_path = None

        def pick_file():
            fp = filedialog.askopenfilename(
                filetypes=[("Todos", "*.pdf *.png *.jpg *.jpeg *.txt *.md"),
                           ("PDF", "*.pdf"), ("Imagen", "*.png *.jpg *.jpeg"),
                           ("Texto", "*.txt *.md")])
            if fp:
                self._ingest_file_path = fp
                txt.delete("1.0", "end")
                txt.insert("1.0", f"[Archivo seleccionado: {fp}]")

        btn_frame = tk.Frame(win, bg=BG)
        btn_frame.pack(fill="x", padx=20, pady=(0, 16))

        tk.Button(btn_frame, text="📂  Abrir archivo",
                  command=pick_file,
                  bg=BG3, fg=FG, font=FONT_UI, relief="flat",
                  cursor="hand2", padx=12, pady=6).pack(side="left")

        def do_ingest():
            content = txt.get("1.0", "end").strip()
            if not content:
                messagebox.showwarning("Vacío", "Ingresá contenido o seleccioná un archivo.")
                return
            win.destroy()
            self._run_ingest(content, self._ingest_file_path)

        tk.Button(btn_frame, text="⚡  Procesar con LM Studio",
                  command=do_ingest,
                  bg=ACCENT, fg=BG, font=("Segoe UI", 10, "bold"),
                  relief="flat", cursor="hand2", padx=16, pady=6).pack(side="right")

    def _run_ingest(self, text_content: str, file_path=None):
        self._set_status("⏳ Procesando con LM Studio...", FG2)

        def worker():
            try:
                context = read_wiki_context()
                messages = [{"role": "system", "content": SCHEMA}]

                # Armar mensaje según tipo de archivo
                if file_path:
                    ext = Path(file_path).suffix.lower()
                    if ext == ".pdf":
                        extracted = extract_pdf_text(file_path)
                        user_content = (f"Ingerí esta fuente PDF ({Path(file_path).name}):\n\n"
                                        f"{extracted}\n\n---\nContexto actual de la wiki:\n{context}")
                        messages.append({"role": "user", "content": user_content})

                    elif ext in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                        b64, mime = image_to_base64(file_path)
                        messages.append({
                            "role": "user",
                            "content": [
                                {"type": "image_url",
                                 "image_url": {"url": f"data:{mime};base64,{b64}"}},
                                {"type": "text",
                                 "text": f"Ingerí esta imagen ({Path(file_path).name}) en la wiki financiera.\n\nContexto actual:\n{context}"}
                            ]
                        })
                    else:
                        user_content = (f"Ingerí esta fuente ({Path(file_path).name}):\n\n"
                                        f"{Path(file_path).read_text()}\n\n---\nContexto actual:\n{context}")
                        messages.append({"role": "user", "content": user_content})
                else:
                    user_content = f"Ingerí esta fuente:\n\n{text_content}\n\n---\nContexto actual de la wiki:\n{context}"
                    messages.append({"role": "user", "content": user_content})

                raw = call_lm_studio(messages)
                result = parse_json_response(raw)

                pages = result.get("paginas", [])
                saved = save_pages(pages)
                resumen = result.get("resumen", "Procesado.")

                self.after(0, lambda: self._ingest_done(saved, resumen))

            except Exception as e:
                self.after(0, lambda: self._set_status(f"❌ Error: {e}", ACCENT3))

        threading.Thread(target=worker, daemon=True).start()

    def _ingest_done(self, saved, resumen):
        self._refresh_tree()
        self._set_status(f"✅ {resumen}  ({len(saved)} páginas actualizadas)", ACCENT2)
        # Mostrar index actualizado
        idx = WIKI_DIR / "index.md"
        if idx.exists():
            self.editor.config(state="normal")
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", idx.read_text())
            self.page_title.config(text=str(idx))

    # ── Query ─────────────────────────────────────────────────────────────────

    def _open_query(self):
        win = tk.Toplevel(self)
        win.title("Consultar wiki")
        win.geometry("580x220")
        win.configure(bg=BG)
        win.grab_set()

        tk.Label(win, text="Consultar la wiki", font=FONT_BIG,
                 bg=BG, fg="#388bfd").pack(pady=(20, 6))

        entry = tk.Entry(win, bg=BG2, fg=FG, font=FONT_MED,
                         insertbackground=ACCENT, relief="flat",
                         borderwidth=0)
        entry.pack(fill="x", padx=20, pady=6, ipady=10)
        entry.focus()

        def do_query(e=None):
            q = entry.get().strip()
            if not q:
                return
            win.destroy()
            self._run_query(q)

        entry.bind("<Return>", do_query)

        tk.Button(win, text="Consultar →",
                  command=do_query,
                  bg="#388bfd", fg=BG, font=("Segoe UI", 10, "bold"),
                  relief="flat", cursor="hand2", padx=16, pady=8).pack(pady=12)

    def _run_query(self, question: str):
        self._set_status("⏳ Consultando...", FG2)

        def worker():
            try:
                context = read_wiki_context()
                # Leer también todas las páginas del wiki para el contexto
                wiki_pages = []
                for f in WIKI_DIR.rglob("*.md"):
                    if f.name not in ("index.md", "log.md"):
                        wiki_pages.append(f"### {f}\n{f.read_text()}")
                full_context = context + "\n\n" + "\n\n".join(wiki_pages[:20])  # máx 20 páginas

                messages = [
                    {"role": "system", "content": SCHEMA},
                    {"role": "user", "content": f"Pregunta: {question}\n\n---\nContenido de la wiki:\n{full_context}"}
                ]
                raw = call_lm_studio(messages, timeout=180)
                result = parse_json_response(raw)
                respuesta = result.get("respuesta", raw)
                self.after(0, lambda: self._query_done(question, respuesta))

            except Exception as e:
                self.after(0, lambda: self._set_status(f"❌ Error: {e}", ACCENT3))

        threading.Thread(target=worker, daemon=True).start()

    def _query_done(self, question, respuesta):
        self._set_status("✅ Consulta completada.", ACCENT2)
        self.editor.config(state="normal")
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", f"# Consulta: {question}\n\n{respuesta}\n\n---\n*{datetime.now().strftime('%Y-%m-%d %H:%M')}*\n")
        self.page_title.config(text=f"Resultado: {question}")

    # ── Lint ──────────────────────────────────────────────────────────────────

    def _run_lint(self):
        self._set_status("⏳ Analizando salud de la wiki...", FG2)

        def worker():
            try:
                context = read_wiki_context()
                all_pages = []
                for f in WIKI_DIR.rglob("*.md"):
                    all_pages.append(f"### {f}\n{f.read_text()}")

                messages = [
                    {"role": "system", "content": SCHEMA},
                    {"role": "user", "content": f"Hacé un lint de la wiki. Buscá contradicciones, páginas huérfanas, claims sin fecha, y sugiere qué investigar.\n\n{chr(10).join(all_pages[:15])}"}
                ]
                raw = call_lm_studio(messages, timeout=180)
                result = parse_json_response(raw)
                problemas   = result.get("problemas",   [])
                sugerencias = result.get("sugerencias", [])
                self.after(0, lambda: self._lint_done(problemas, sugerencias))

            except Exception as e:
                self.after(0, lambda: self._set_status(f"❌ Error: {e}", ACCENT3))

        threading.Thread(target=worker, daemon=True).start()

    def _lint_done(self, problemas, sugerencias):
        self._set_status(f"✅ Lint: {len(problemas)} problemas, {len(sugerencias)} sugerencias.", ACCENT2)
        lines = ["# Reporte de Lint\n"]
        if problemas:
            lines.append("## ⚠️ Problemas encontrados")
            for p in problemas:
                lines.append(f"- {p}")
        else:
            lines.append("## ✅ Sin problemas detectados")
        if sugerencias:
            lines.append("\n## 💡 Sugerencias")
            for s in sugerencias:
                lines.append(f"- {s}")
        self.editor.config(state="normal")
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", "\n".join(lines))
        self.page_title.config(text="Reporte de Lint")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _set_status(self, msg: str, color=FG2):
        self.status.config(text=msg, fg=color)
        self.update_idletasks()


# ── Entrada ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = WikiApp()
    app.mainloop()
