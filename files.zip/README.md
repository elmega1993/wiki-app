# Finanzas Wiki — App de escritorio

App de escritorio Python que conecta con LM Studio para construir
una wiki de finanzas personal de forma incremental.

## Requisitos

- Python 3.10+
- LM Studio corriendo en `http://localhost:1234`
- (Opcional) `pdfminer.six` para extraer texto de PDFs:
  ```
  pip install pdfminer.six
  ```

## Uso

```bash
python wiki_app.py
```

## Operaciones

| Botón | Qué hace |
|-------|----------|
| ＋ Ingerir fuente | Procesa texto, PDF o imagen y actualiza la wiki |
| 🔍 Consultar wiki | Hace una pregunta sobre el contenido acumulado |
| 🛠 Lint | Analiza la wiki buscando contradicciones y páginas huérfanas |
| ⟳ Actualizar árbol | Refresca el árbol de archivos del panel izquierdo |

## Estructura generada

```
wiki/
  entidades/   ← empresas, ETFs, activos
  conceptos/   ← inflación, tasas, CEDEARs
  fuentes/     ← resúmenes de cada fuente
  index.md     ← índice general
  log.md       ← historial de operaciones
raw/           ← tus fuentes originales (inmutables)
```

## Configuración

Editá las primeras líneas de `wiki_app.py` para cambiar:
- `LM_STUDIO_URL` — si LM Studio corre en otra IP/puerto
- `MODEL_NAME`    — el modelo que tengas cargado
